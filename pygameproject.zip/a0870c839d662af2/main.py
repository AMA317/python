import pygame
import time
from random import randint
pygame.init()
volume = 0.5
pygame.mixer.music.load('1.mp3')
pygame.mixer.music.load('2.mp3')
pygame.mixer.music.load('3.mp3')
screen = pygame.display.set_mode((1400, 800))
clock = pygame.time.Clock()
coin = pygame.image.load('coin.png')
score = 0
name = 'игра'
pygame.display.set_caption(name)
pygame_icon = pygame.image.load('icon.png')
pygame.display.set_icon(pygame_icon)
#первый экран
bg_1 = pygame.image.load('bg-2.jpg')
box = pygame.image.load('box.jpg')
box_1 = pygame.image.load('box_1.jpg')
my_font = pygame.font.SysFont('arial', 65)
text = my_font.render('2 lvl', False , (255,255,255))
text_2 = my_font.render('3 lvl', False,(255,255,255))
lvl_1 = []
for i in range(7):
    lvl_1.append(box)
x_box = 0
y_box = 70
flag_1 = 1
coins_1 = []
x_coin = 100
for i in range(10):
    if i == 6:
        x_coin = 310
    if i < 6:
        y_coin = 100
    else:
        y_coin = 650
    coinn = [x_coin,y_coin]
    coins_1.append(coinn)
    x_coin += 210
#второй экран
bg_2 = pygame.image.load('bg-1.jpg')
provoloka = pygame.image.load('проволока.png')
provoloka_1 = pygame.image.load('проволока_1.png')
font = pygame.font.SysFont('arial', 180)
font_score = pygame.font.SysFont('arial', 100)
text_1 = font.render('Game over', False , (255,255,255))
text_3 = font.render('Victory', False , (255,255,255))
lvl_2 = []
flag_2 = 1
flag_22 = 1
speed_2 = 1.5
numb = 0
coins_2 = []
x_coin = 100
for i in range(10):
    if i == 6:
        x_coin = 310
    if i < 6:
        y_coin = 100
    else:
        y_coin = 650
    coinn = [x_coin,y_coin]
    coins_2.append(coinn)
    x_coin += 210
for i in range(7):
    lvl_2.append(provoloka)
x_prov = 0
y_prov = -30
x_prov_1 = 210
y_prov_1 = 340
a = 1
#третий экран
win = 0
coins_3 = []
x_coin = 100
for i in range(10):
    if i == 6:
        x_coin = 310
    if i < 6:
        y_coin = 100
    else:
        y_coin = 650
    coinn = [x_coin,y_coin]
    coins_3.append(coinn)
    x_coin += 210
bg_3 = pygame.image.load('bg-3.jpg')
saw = []
for i in range(10):
    img = pygame.image.load('saw_0'+str(i)+'.png')
    saw.append(img)
slow_saw = 3
saw_place = []
for i in range(10):
    x_saw = randint(100,1100)
    if x_saw > 100:
        y_saw = randint(0,640)
    else:
        y_saw = randint(0,400)
    saw_1 = [x_saw,y_saw]
    saw_place.append(saw_1)
#персонаж
green_elf_list = []
for i in range(10):
    img = pygame.image.load('Green_elf_'+ str(i) + '.png')
    green_elf_list.append(img)
FPS = 30
x = 0
y = 568
sum = 1
speed = 10
screen_number = 1
running = True
slow = 3
number_iter = 0
screen_1 = screen_2 = screen_3 = 1  
move_right = move_left = move_up = move_down = False
while running: 
    clock.tick(FPS)
    number_frame = number_iter // slow % 10
    number_frame_saw = number_iter // slow_saw % 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                move_up = True
            if event.key == pygame.K_s:
                move_down = True
            if event.key == pygame.K_a:
                move_left = True
            if event.key == pygame.K_d:
                move_right = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_w:
                move_up = False
            if event.key == pygame.K_s:
                move_down = False
            if event.key == pygame.K_a:
                move_left = False
            if event.key == pygame.K_d:
                move_right = False
    if screen_number == 1:
        if screen_1 == 1:
            pygame.mixer.music.load('1.mp3')
            pygame.mixer.music.set_volume(volume)
            pygame.mixer.music.play(loops=-1)
            screen_1 = 0
        screen.blit(bg_1,(0,0))
        screen.blit(green_elf_list[number_frame],(x,y))
        for i in range(10):
            screen.blit(coin,(coins_1[i][0],coins_1[i][1]))
        for elem in lvl_1:
            screen.blit(elem,(x_box,y_box))
            x_box += 210
            if flag_1 == -1:
                y_box = 70
            else:
                y_box = 240
            flag_1 *= -1
            if flag_1 == -1:
                if -165 < x - (x_box-140) < -5 and y - (y_box+320) < -5:
                    x = 0
                    y = 568
            if flag_1 == 1:
                if y+122 - (y_box+170) >= 0 and -165 < x - (x_box-140) < -5:
                    x = 0
                    y = 568        
        screen.blit(box_1,(0,0))
        screen.blit(box_1,(0,730))
        if y < 70 or y + 131 > 730 or x < 0 or x+100 > 1400:
            x = 0
            y = 568
        if move_up:
            y -= speed
        if move_down:
            y += speed
        if move_right:
            x += speed
        if move_left:
            x -= speed
        pygame.draw.rect(screen, (104,108,94), [1230,560,170,170])
        screen.blit(text,(1270,610))
        for i in range(10):
            if x+100 - coins_1[i][0] > 0 and coins_1[i][0] + 50 - x > 0 and y + 122 - coins_1[i][1] > 0 and coins_1[i][1] + 50 - y > 0:
                coins_1[i][0] = -50
                coins_1[i][1] = -50
                score += 1
        if 1230 < x < 1400 and 560 < y < 730:
            screen_number = 2
            x = 0
            y = 568
    if screen_number == 2:
        if screen_2 == 1:
            pygame.mixer.music.stop()  # останавливаем старый трек
            pygame.mixer.music.load('2.mp3')
            pygame.mixer.music.set_volume(volume)
            pygame.mixer.music.play(loops=-1)
            screen_2 = 0
        screen.blit(bg_2,(0,0))
        pygame.draw.rect(screen, (128,0,0), [1230,560,170,170])
        screen.blit(text_2,(1270,610))
        screen.blit(green_elf_list[number_frame],(x,y))
        for i in range(10):
            screen.blit(coin,(coins_2[i][0],coins_2[i][1]))
        for elem in lvl_2:
            if x+100 - x_prov >= 10 and x_prov + 70 - x >= 10 and y + 122 - y_prov >= 10 and y_prov + 470 - y >= 10:
                a = 0
            if x+100 - x_prov_1 >= 10 and x_prov_1 + 70 - x >= 10 and y + 122 - y_prov_1 >= 10 and y_prov_1 + 470 - y >= 10:
                a = 0 
            if numb%2 == 0:
                screen.blit(elem,(x_prov,y_prov))
                x_prov += 420
            else:
                screen.blit(elem,(x_prov_1,y_prov_1))
                x_prov_1 += 420
            if y_prov+470 == 800:
                speed_2 = -1.5
            if y_prov <= 0:
                speed_2 = 1.5
            y_prov += speed_2
            y_prov_1 -= speed_2
            numb += 1
        screen.blit(provoloka_1,(0,0))
        screen.blit(provoloka_1,(0,730))
        if move_up and y > 70:
            y -= speed
        if move_down and y+122 < 730:
            y += speed
        if move_right and x+100 < 1400:
            x += speed
        if move_left and x > 0:
            x -= speed
        for i in range(10):
            if x+100 - coins_2[i][0] > 0 and coins_2[i][0] + 50 - x > 0 and y + 122 - coins_2[i][1] > 0 and coins_2[i][1] + 50 - y > 0:
                coins_2[i][0] = -50
                coins_2[i][1] = -50
                score += 1
        if 1230 < x+100 < 1400 and 560 < y+122 < 730:
            screen_number = 3
            x = 0
            y = 568
    if screen_number == 3:
        if screen_3 == 1:
            pygame.mixer.music.stop()  # останавливаем старый трек
            pygame.mixer.music.load('3.mp3')
            pygame.mixer.music.set_volume(volume)
            pygame.mixer.music.play(loops=-1)
            screen_3 = 0
        screen.blit(bg_3,(0,0))
        screen.blit(green_elf_list[number_frame],(x,y))
        for i in range(10):
            speed_x = randint(-9,9)
            speed_y = randint(-9,9)
            if 0 < saw_place[i][0] < 1250:
                saw_place[i][0]+=speed_x
            if 0 < saw_place[i][1] < 650:
                saw_place[i][1]+=speed_y
        for i in range(10):
            screen.blit(saw[number_frame_saw],(saw_place[i][0],saw_place[i][1]))
        for i in range(10):
            if x+100 - saw_place[i][0] > 10 and saw_place[i][0] + 150 - x > 10 and y + 122 - saw_place[i][1] > 10 and saw_place[i][1] + 150 - y > 10:
                a = 0
        if move_up and y > 0:
            y -= speed
        if move_down and y + 122 < 800:
            y += speed
        if move_right and x + 100 < 1400:
            x += speed
        if move_left and x > 0:
            x -= speed
        for i in range(10):
            screen.blit(coin,(coins_3[i][0],coins_3[i][1]))
        for i in range(10):
            if x+100 - coins_3[i][0] > 0 and coins_3[i][0] + 50 - x > 0 and y + 122 - coins_3[i][1] > 0 and coins_3[i][1] + 50 - y > 0:
                coins_3[i][0] = -50
                coins_3[i][1] = -50
                score += 1
        if score == 30:
            win = 1
            
    x_box = 0
    y_box = 70
    x_prov = 0
    x_prov_1 = 210
    flag_2 = 1
    flag_1 = 1
    numb = 0
    sum = 1
    number_iter += 1
    text_4 = font.render('Счет: ' + str(score), False , (255,255,255))
    if a == 0:
        pygame.mixer.music.stop()
        screen.fill((0,0,0))
        screen.blit(text_1,(350,150))
        screen.blit(text_4,(350,350))
        running = False
    if win == 1:
        pygame.mixer.music.stop()
        screen.fill((0,153,76))
        screen.blit(text_3,(450,150))
        screen.blit(text_4,(450,350))
        running = False
    pygame.display.flip()
time.sleep(2)
pygame.quit()